package com.samfa12.hordelanternrt;
import android.content.Intent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class IndirectLightingTrialIntentTest {
    private Intent trial(String mode) {
        return new Intent(IndirectLightingTrialIntent.ACTION).putExtra(IndirectLightingTrialIntent.EXTRA, mode);
    }
    @Test public void defaultAndExplicitFiniteModes() {
        assertEquals(0, IndirectLightingTrialIntent.parse(null, false));
        assertEquals(0, IndirectLightingTrialIntent.parse(new Intent(), false));
        assertEquals(0, IndirectLightingTrialIntent.parse(trial("current"), true));
        assertEquals(1, IndirectLightingTrialIntent.parse(trial("lower"), true));
    }
    @Test public void unapprovedBuildActionTypeAndSpellingFailClosed() {
        assertThrows(IllegalArgumentException.class, () -> IndirectLightingTrialIntent.parse(trial("lower"), false));
        assertThrows(IllegalArgumentException.class, () -> IndirectLightingTrialIntent.parse(trial("current"), false));
        assertThrows(IllegalArgumentException.class, () -> IndirectLightingTrialIntent.parse(trial("lower").setAction(Intent.ACTION_MAIN), true));
        for (String bad : new String[] {"Lower", "", " low", "2"})
            assertThrows(IllegalArgumentException.class, () -> IndirectLightingTrialIntent.parse(trial(bad), true));
        Intent wrongType = new Intent(IndirectLightingTrialIntent.ACTION).putExtra(IndirectLightingTrialIntent.EXTRA, 1);
        assertThrows(IllegalArgumentException.class, () -> IndirectLightingTrialIntent.parse(wrongType, true));
    }
}
