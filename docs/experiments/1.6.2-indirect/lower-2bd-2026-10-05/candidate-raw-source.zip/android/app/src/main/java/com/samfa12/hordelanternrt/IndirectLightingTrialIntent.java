package com.samfa12.hordelanternrt;
import android.content.Intent;
final class IndirectLightingTrialIntent {
    static final String EXTRA = "horde.benchmark.indirect_lighting_trial";
    static final String ACTION = "com.samfa12.hordelanternrt.action.BENCHMARK";
    private IndirectLightingTrialIntent() {}
    static int parse(Intent intent, boolean supported) {
        if (intent == null || !intent.hasExtra(EXTRA)) return 0;
        if (!supported || !ACTION.equals(intent.getAction()))
            throw new IllegalArgumentException("Indirect trial requires the isolated Benchmark finite run.");
        Object raw = intent.getExtras().get(EXTRA);
        if (!(raw instanceof String)) throw new IllegalArgumentException("Indirect trial must be a string.");
        if ("current".equals(raw)) return 0;
        if ("lower".equals(raw)) return 1;
        throw new IllegalArgumentException("Indirect trial must be exactly current or lower.");
    }
}
