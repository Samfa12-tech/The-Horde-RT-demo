#pragma once

#include <cmath>
#include <cstdint>
#include <optional>
#include "vulkan/raytracing/RtSceneAbi.generated.h"

namespace horde::vulkan::raytracing
{
// Separate trial only: not a GraphicsSettings schema or whole-workload choice.
enum class RtIndirectLightingTrial : std::uint32_t { Current = 0u, Lower = 1u };

inline std::optional<RtQualityControlsGpu> WithIndirectLightingTrial(
    RtQualityControlsGpu quality, const RtIndirectLightingTrial trial) noexcept
{
    if (static_cast<std::uint32_t>(trial) > 1u || quality.controls[3] != 0u)
        return std::nullopt;
    quality.controls[3] = static_cast<std::uint32_t>(trial);
    return quality;
}

// CPU classification oracle for the private shader trial. IDs/flags are from
// the pinned base GLSL/ABI; this helper is not a geometry or shader execution test.
struct IndirectReceiverClassification
{
    bool hit = true;
    bool wantsPlayerReflection = false;
    int material = 100;
    std::uint32_t materialFlags = 0u;
    float metallic = 0.0f;
    float reflectivity = 0.04f;
    float roughness = 1.0f;
    float transmission = 0.0f;
    float emissive = 0.0f;
};
inline bool CanOmitOpaquePrimarySecondary(const RtIndirectLightingTrial trial,
    const IndirectReceiverClassification& h) noexcept
{
    if (trial != RtIndirectLightingTrial::Lower || !h.hit || h.wantsPlayerReflection)
        return false;
    if (!std::isfinite(h.metallic) || !std::isfinite(h.reflectivity) ||
        !std::isfinite(h.roughness) || !std::isfinite(h.transmission) ||
        !std::isfinite(h.emissive)) return false;
    // ALL positive metallic samples and all transmitting/alpha fallbacks stay.
    if (h.metallic != 0.0f || h.transmission != 0.0f || h.emissive != 0.0f ||
        (h.materialFlags & (2u | 4u)) != 0u) return false;
    if (h.material < 0 || (h.material > 10 && h.material < 100) ||
        h.material >= 100 + static_cast<int>(kRtMaterialCapacity)) return false;
    // WetCobble1, Mirror8, ClearGlass9, Water10; imported IDs start at100.
    if (h.material == 1 || h.material == 8 || h.material == 9 || h.material == 10)
        return false;
    return h.reflectivity >= 0.0f && h.reflectivity <= 0.12f &&
           h.roughness >= 0.65f && h.roughness <= 1.0f;
}
} // namespace horde::vulkan::raytracing
