#pragma once
#include "telemetry/RtPerformanceEvidence.h"
namespace horde::telemetry {
inline bool HasCompletedIndirectLightingTrialAck(const RtLifecyclePublishedState& publication,
    const RtIndirectLightingMode requested) noexcept {
    if (!publication.running || !publication.presented || !publication.hasCompletedEvidence ||
        !publication.completedEvidence.scene.indirectLightingTrial) return false;
    const auto& frame = publication.completedEvidence;
    const auto& trial = *frame.scene.indirectLightingTrial;
    return ValidRtIndirectLightingEvidence(trial) && trial.mode == requested &&
        frame.identity.submitted.frame.sceneEpoch == publication.sceneEpoch &&
        frame.identity.submitted.frame.measurementGeneration == publication.measurementGeneration &&
        frame.identity.submitted.frame.recordSerial != 0u && frame.identity.completionSerial != 0u &&
        frame.identity.submitted.submissionSerial != 0u &&
        frame.presentation.outcome == RtPresentationOutcome::Presented &&
        frame.presentation.lastSuccessfulPresentSubmissionSerial == frame.identity.submitted.submissionSerial;
}
}
