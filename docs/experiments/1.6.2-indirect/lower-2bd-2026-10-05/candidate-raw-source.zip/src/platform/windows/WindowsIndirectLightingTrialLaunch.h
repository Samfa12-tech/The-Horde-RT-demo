#pragma once
#include <span>
#include <string>
#include <string_view>
#include "vulkan/raytracing/RtIndirectLightingTrial.h"
namespace horde::platform::windows {
struct WindowsIndirectLightingTrialLaunch {
    bool requested = false;
    horde::vulkan::raytracing::RtIndirectLightingTrial mode = horde::vulkan::raytracing::RtIndirectLightingTrial::Current;
    std::string error;
};
inline WindowsIndirectLightingTrialLaunch ParseWindowsIndirectLightingTrialLaunch(
    std::span<const std::wstring_view> args) {
    WindowsIndirectLightingTrialLaunch result; unsigned finiteModes = 0u; bool motion = false;
    for (std::size_t i = 0; i < args.size(); ++i) {
        if (args[i] == L"--capture-showcase" || args[i] == L"--capture-graphics-preview" ||
            args[i] == L"--benchmark-showcase") ++finiteModes;
        if (args[i] == L"--validate-native-motion") motion = true;
        if (args[i] != L"--trial-indirect") continue;
        if (result.requested || i+1 >= args.size()) { result.error = "Trial mode is duplicate or missing."; return result; }
        result.requested = true; const auto value = args[++i];
        if (value == L"current") result.mode = horde::vulkan::raytracing::RtIndirectLightingTrial::Current;
        else if (value == L"lower") result.mode = horde::vulkan::raytracing::RtIndirectLightingTrial::Lower;
        else { result.error = "Trial mode must be exactly current or lower."; return result; }
    }
    if (result.requested && (finiteModes != 1u || motion))
        result.error = "Trial mode requires exactly one finite static capture or benchmark run, without motion evidence.";
    return result;
}
}
