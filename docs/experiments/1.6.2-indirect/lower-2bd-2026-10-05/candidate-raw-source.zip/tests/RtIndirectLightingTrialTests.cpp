#include "vulkan/raytracing/RtIndirectLightingTrial.h"
#include "vulkan/raytracing/RtSceneTuning.h"
#include "telemetry/RtIndirectLightingTrialAck.h"
#include "platform/windows/WindowsIndirectLightingTrialLaunch.h"
#include <array>
#include <cmath>
#include <iostream>
#include <limits>

using namespace horde::vulkan::raytracing;
namespace {
unsigned checks = 0, failures = 0;
void Check(bool value, const char* message) {
    ++checks; if (!value) { ++failures; std::cerr << message << '\n'; }
}
}
int main()
{
    using Trial = RtIndirectLightingTrial;
    const IndirectReceiverClassification diffuse{};
    Check(!CanOmitOpaquePrimarySecondary(Trial::Current, diffuse), "default Current preserves secondary");
    Check(CanOmitOpaquePrimarySecondary(Trial::Lower, diffuse), "nonmetal rough imported receiver eligible");
    Check(!CanOmitOpaquePrimarySecondary(static_cast<Trial>(2), diffuse), "unknown GPU policy keeps bounce");
    auto h = diffuse; h.wantsPlayerReflection = true;
    Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "player-reflection selection always protected");
    for (const float metal : {std::numeric_limits<float>::denorm_min(), 0.000001f, 0.05f, 1.0f}) {
        h = diffuse; h.metallic = metal;
        Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "ALL positive metal values protected");
    }
    for (const int material : {1, 8, 9, 10}) {
        h = diffuse; h.material = material;
        Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h),
              "wet/mirror/glass/water classification protected; no water-mode-dependent gate");
    }
    for (const unsigned flag : {2u, 4u, 6u}) {
        h = diffuse; h.materialFlags = flag;
        Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "alpha/transmission fallback protected even when transmission value0");
    }
    h = diffuse; h.transmission = 0.000001f;
    Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "unflagged positive transmission protected");
    h = diffuse; h.emissive = 0.000001f;
    Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "emission path protected");
    h = diffuse; h.reflectivity = 0.12f; h.roughness = 0.65f;
    Check(CanOmitOpaquePrimarySecondary(Trial::Lower, h), "inclusive finite eligibility boundary");
    h.reflectivity = std::nextafter(0.12f, 1.0f);
    Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "next float above weak reflection bound protected");
    h.reflectivity = 0.12f; h.roughness = std::nextafter(0.65f, 0.0f);
    Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "next float below matte roughness bound protected");
    for (const float invalid : {-1.0f, std::numeric_limits<float>::infinity(), std::numeric_limits<float>::quiet_NaN()}) {
        h = diffuse; h.metallic = invalid;
        Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "invalid metallic preserves transport");
        h = diffuse; h.transmission = invalid;
        Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "invalid transmission preserves transport");
        h = diffuse; h.reflectivity = invalid;
        Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "invalid reflectivity preserves transport");
        h = diffuse; h.roughness = invalid;
        Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "invalid roughness preserves transport");
    }
    for (const int material : {-1, 11, 99, 132}) {
        h = diffuse; h.material = material;
        Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "unknown material retains transport");
    }
    h = diffuse; h.hit = false;
    Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "miss retains sky path");
    h = diffuse; h.roughness = 1.01f;
    Check(!CanOmitOpaquePrimarySecondary(Trial::Lower, h), "out of range roughness protected");
    // Actual factories: independent trial must not change any existing shadow budget.
    for (const bool high : {false, true}) for (const auto shadow : {
        horde::graphics::ShadowQuality::Lower, horde::graphics::ShadowQuality::Current,
        horde::graphics::ShadowQuality::Higher}) {
        const auto current = ResolveRtQualityControls(shadow, RtWorkloadPreset::Authored, high);
        const auto lower = ResolveRtQualityControls(shadow, RtWorkloadPreset::Authored, high, Trial::Lower);
        Check(current && lower && current->controls[3] == 0u && lower->controls[3] == 1u,
              "actual factory uploads distinct Current0/Lower1");
        Check(current && lower && std::equal(current->controls.begin(), current->controls.begin()+3,
              lower->controls.begin()), "shadow mode/local/sky counts unchanged");
    }
    Check(!ResolveRtQualityControls(horde::graphics::ShadowQuality::Current,
        RtWorkloadPreset::Authored, true, static_cast<Trial>(255)), "unknown CPU trial enum rejected");
    const RtQualityControlsGpu old{{1u, 1u, 1u, 0u}};
    const auto roundTrip = WithIndirectLightingTrial(old, Trial::Current);
    Check(roundTrip && roundTrip->controls == old.controls, "Current quality record bit-identical");
    auto dirty = old; dirty.controls[3] = 5u;
    Check(!WithIndirectLightingTrial(dirty, Trial::Lower), "unexpected prior reserved word rejected");
    using namespace horde::telemetry;
    RtLifecyclePublishedState publication{};
    publication.running = publication.presented = publication.hasCompletedEvidence = true;
    publication.sceneEpoch = 7u; publication.measurementGeneration = 3u;
    auto& frame = publication.completedEvidence;
    frame.identity = {{{7u, 3u, 11u, 11u, 60u, 0u}, 12u}, 13u};
    frame.scene.indirectLightingTrial = RtIndirectLightingEvidence{RtIndirectLightingMode::Lower, 1u};
    frame.presentation = {RtPresentationOutcome::Presented, 12u, false};
    Check(HasCompletedIndirectLightingTrialAck(publication, RtIndirectLightingMode::Lower),
          "matching real completed presented Lower record admits ACK");
    Check(!HasCompletedIndirectLightingTrialAck(publication, RtIndirectLightingMode::Current), "requested Current cannot ACK uploaded Lower");
    const auto good = publication;
    const auto reject = [&](const char* reason) {
        Check(!HasCompletedIndirectLightingTrialAck(publication, RtIndirectLightingMode::Lower), reason);
        publication = good;
    };
    publication.completedEvidence.scene.indirectLightingTrial.reset(); reject("requested intent without uploaded evidence rejected");
    publication.completedEvidence.scene.indirectLightingTrial->qualityWord = 0u; reject("mode/word mismatch rejected");
    publication.completedEvidence.scene.indirectLightingTrial->mode = static_cast<RtIndirectLightingMode>(2u); reject("unknown evidence enum rejected");
    publication.sceneEpoch++; reject("stale scene completion rejected");
    publication.measurementGeneration++; reject("stale measurement completion rejected");
    publication.completedEvidence.identity.completionSerial = 0u; reject("pending completion rejected");
    publication.completedEvidence.identity.submitted.submissionSerial = 0u; reject("unsubmitted record rejected");
    publication.completedEvidence.identity.submitted.frame.recordSerial = 0u; reject("unrecorded record rejected");
    publication.completedEvidence.presentation.outcome = RtPresentationOutcome::NotAttempted; reject("completion without present rejected");
    publication.completedEvidence.presentation.outcome = RtPresentationOutcome::PresentedNeedsRecreate; reject("recreate boundary rejected");
    publication.completedEvidence.presentation.lastSuccessfulPresentSubmissionSerial++; reject("different presented submission rejected");
    publication.running = false; reject("stopped owner rejected");
    publication.hasCompletedEvidence = false; reject("no completed publication rejected");
    publication.presented = false; reject("no current RT presentation rejected");
    publication.completedEvidence.presentation.finalIdleCompletion = true;
    Check(HasCompletedIndirectLightingTrialAck(publication, RtIndirectLightingMode::Lower),
          "final owner drain may complete an actually presented submission");
    const auto parse = [](std::initializer_list<std::wstring_view> args) {
        return horde::platform::windows::ParseWindowsIndirectLightingTrialLaunch({args.begin(), args.size()});
    };
    Check(parse({L"--trial-indirect", L"lower", L"--benchmark-showcase", L"out"}).error.empty(), "finite benchmark Lower admitted");
    Check(parse({L"--capture-showcase", L"out", L"--trial-indirect", L"current"}).error.empty(), "finite capture Current admitted");
    Check(parse({L"--validate-native-motion", L"out"}).error.empty(), "historical motion without trial unchanged");
    for (const auto& bad : {
        parse({L"--trial-indirect", L"lower"}), parse({L"--trial-indirect"}),
        parse({L"--trial-indirect", L"Lower", L"--benchmark-showcase", L"out"}),
        parse({L"--trial-indirect", L"lower", L"--trial-indirect", L"current", L"--capture-showcase", L"out"}),
        parse({L"--trial-indirect", L"lower", L"--capture-showcase", L"out", L"--benchmark-showcase", L"out"}),
        parse({L"--trial-indirect", L"lower", L"--validate-native-motion", L"out"})})
        Check(!bad.error.empty(), "orphan/unknown/duplicate/mixed/motion trial rejected before Vulkan");
    std::cout << checks << " boundary assertions, " << failures << " failures\n";
    return failures ? 1 : 0;
}
