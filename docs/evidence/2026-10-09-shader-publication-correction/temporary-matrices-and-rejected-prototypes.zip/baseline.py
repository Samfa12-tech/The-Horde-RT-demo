import subprocess,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2]; dest=Path(__file__).parent/'baseline-source-fixture'; dest.mkdir(exist_ok=False)
runtime='1c28d0563a897dc72d410bdb2b61723e66ed92af'; start='d271a08bd18f15bd49411000b174b89a39878479'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',runtime,'shaders'],cwd=root,text=True).splitlines()
rows=[]
for source,paths in [(runtime,paths),(start,['tools/compile-raygen.ps1','tools/raygen-variants.json'])]:
 for path in paths:
  data=subprocess.check_output(['git','show',source+':'+path],cwd=root);target=dest/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  rows.append(dict(path=path,source=source,git_blob=subprocess.check_output(['git','rev-parse',source+':'+path],cwd=root,text=True).strip(),sha256=hashlib.sha256(data).hexdigest()))
(Path(__file__).parent/'baseline-source-identities.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Immutable baseline shader source fixture; no checkout/executor created: '+str(dest))
