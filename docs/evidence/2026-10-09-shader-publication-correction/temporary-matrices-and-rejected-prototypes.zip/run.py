import subprocess,sys,time,json,datetime,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2]; out=Path(__file__).parent
label=sys.argv[1]; argv=sys.argv[2:]; base='d271a08bd18f15bd49411000b174b89a39878479'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
diff=subprocess.check_output(['git','-c','core.autocrlf=false','diff','--binary',base],cwd=root)
log=out/(label+'.log'); start=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.perf_counter()
with log.open('wb') as stream: result=subprocess.run(argv,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
row=dict(label=label,argv=argv,cwd=str(root),started_utc=start,wall_seconds=time.perf_counter()-clock,exit_status=result.returncode,starting_head=head,base=base,candidate_diff_sha256=hashlib.sha256(diff).hexdigest(),log=log.name,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (out/'runs.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
print(json.dumps(row));sys.exit(result.returncode)
