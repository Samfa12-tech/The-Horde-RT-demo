import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]; evidence=root/'docs/evidence/2026-10-09-shader-publication-correction'
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=json.loads((evidence/'full-metrics.json').read_text())['rows']
assert len(rows)==8 and len({r['key'] for r in rows})==8
for r in rows:
    assert r['fresh']['baseline']['compiledSpirvSha256']==r['retained']['spirvSha256']
    assert not r['violations']['baseline']
    assert r['violations']['before']==['bytes','words','instructions']
    opaque=r['exact']['material']=='OpaqueFast'
    assert r['violations']['after']==(['bytes','words','instructions'] if opaque else [])
    if opaque:
        assert [r['fresh']['after'][k]-r['max'][k] for k in ['bytes','words','instructions']]==[28,7,2]
    for stage in ['baseline','before','after']:
        assert all(r['fresh'][stage][k]==v for k,v in r['exact'].items())
        assert all(r['fresh'][stage][k]<=v for k,v in r['max'].items() if k not in ['bytes','words','instructions'])
archive=json.loads((evidence/'archive-manifest.json').read_text())
assert sha((evidence/archive['archive']).read_bytes())==archive['sha256']
with zipfile.ZipFile(evidence/archive['archive']) as z:
    for m in archive['members']:
        b=z.read(m['path']); assert len(b)==m['bytes'] and sha(b)==m['sha256']
    for r in rows:
        for stage in ['baseline','before','after']:
            data=z.read('matrix-'+stage+'/'+r['key']+'/minimal.rgen.spv')
            assert sha(data)==r['fresh'][stage]['compiledSpirvSha256'] and len(data)==r['fresh'][stage]['bytes']
receipt=json.loads((evidence/'receipt.json').read_text())
assert all(sha((evidence/name).read_bytes())==identity for name,identity in receipt['files'].items())
assert not subprocess.check_output(['git','diff','d271a08bd18f15bd49411000b174b89a39878479','--','src','shaders','tests','tools','assets','android','windows','CMakeLists.txt','CMakePresets.json'],cwd=root)
print('PASS: 8 baseline raw identities; 24 complete row/invariant comparisons; exact 4-row Opaque remainder; '+str(len(archive['members']))+' archive members and module identities; receipt hashes; empty protected source diff. No native/device acceptance implied.')
