import hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2]; out=Path(__file__).parent
base='d271a08bd18f15bd49411000b174b89a39878479'
paths=subprocess.check_output(['git','diff','--name-only',base],cwd=root,text=True).splitlines()
allowed={'shaders/raytracing/include/rt_atmosphere.glsl','shaders/raytracing/include/rt_frame.glsl','shaders/raytracing/include/rt_hit_decode.glsl','shaders/raytracing/include/rt_scene_abi.generated.glsl','src/vulkan/raytracing/PresentableTinyRtScene.cpp','src/vulkan/raytracing/RtSceneAbi.def','src/vulkan/raytracing/RtSceneAbi.generated.h','src/vulkan/raytracing/SimulationFrameAdapter.h'}
assert set(paths)<=allowed,paths
(out/'unaccepted-prototype.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--binary',base],cwd=root))
identities=[]
for name in sorted(allowed):
    path=root/name
    current=path.read_bytes()
    archive=out/'unaccepted-source'/name; archive.parent.mkdir(parents=True,exist_ok=True); archive.write_bytes(current)
    original=subprocess.check_output(['git','show',base+':'+name],cwd=root)
    identities.append({'path':name,'prototype_sha256':hashlib.sha256(current).hexdigest(),'restored_git_blob':subprocess.check_output(['git','rev-parse',base+':'+name],cwd=root,text=True).strip(),'restored_sha256':hashlib.sha256(original).hexdigest()})
    path.write_bytes(original)
(out/'restoration-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
print('Preserved measurement-only source and restored only task-owned experiments from '+base)
