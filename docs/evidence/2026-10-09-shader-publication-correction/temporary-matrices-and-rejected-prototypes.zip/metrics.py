import json
from pathlib import Path
root=Path(__file__).resolve().parents[2]; out=Path(__file__).parent
budgets=json.loads((root/'tools/raygen-variant-budgets.json').read_text())
retained=json.loads((root/'tools/raygen-variant-catalog.json').read_text())
rows=[]
for cap in budgets['budgets']:
 key=cap['key']; variants={name:json.loads((out/('matrix-'+name)/key/'raygen-stats.json').read_text()) for name in ['baseline','before']}
 if (out/'matrix-after'/key/'raygen-stats.json').is_file(): variants['after']=json.loads((out/'matrix-after'/key/'raygen-stats.json').read_text())
 prior=next(x for x in retained['variants'] if x['key']==key)
 row={'key':key,'max':cap['max'],'exact':cap['exact'],'retained':prior,'fresh':variants,'violations':{}}
 for name,v in variants.items():
  row['violations'][name]=[k for k in cap['max'] if v[k]>cap['max'][k]]+[k for k in cap['exact'] if v.get(k,prior.get(k))!=cap['exact'][k]]
 rows.append(row)
 print(key, {name:{'bytes':v['bytes'],'instructions':v['instructions'],'violations':row['violations'][name]} for name,v in variants.items()})
(out/'full-metrics.json').write_text(json.dumps(rows,indent=2)+'\n')
