import collections,hashlib,json,re,shutil,subprocess,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]; out=Path(__file__).parent
base='d271a08bd18f15bd49411000b174b89a39878479'
evidence=root/'docs/evidence/2026-10-09-shader-publication-correction'; evidence.mkdir(parents=True,exist_ok=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def save(name,value): (evidence/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
manifest=json.loads((root/'tools/raygen-variants.json').read_text())
shipping={r['name']:r['shippingAllowed'] for r in manifest['variants']}
metrics=json.loads((out/'full-metrics.json').read_text())
for row in metrics:
    for name,stats in row['fresh'].items():
        stats['shippingAllowed']=shipping[row['key']]
        row['violations'][name]=[k for k,v in row['max'].items() if stats[k]>v]+[k for k,v in row['exact'].items() if stats[k]!=v]
save('full-metrics.json',{'schema':1,'shippingAllowed_source':'unchanged tools/raygen-variants.json (not a measured SPIR-V property)','rows':metrics})
tools=[]
for filename in ['glslangValidator.exe','spirv-opt.exe','spirv-val.exe','spirv-dis.exe']:
    path=Path('C:/VulkanSDK/1.4.350.0/Bin')/filename
    result=subprocess.run([str(path),'--version'],capture_output=True,text=True)
    tools.append({'path':str(path),'sha256':sha(path.read_bytes()),'version_argv':[str(path),'--version'],'exit_status':result.returncode,'version':result.stdout+result.stderr})
save('toolchain.json',{'sdk':'C:/VulkanSDK/1.4.350.0','engine':'C:/Program Files/PowerShell/7/pwsh.exe','tools':tools,'strategies':{'GenericRetained':{'glslang':['-V','--target-env','vulkan1.2','-S','rgen'],'spirv_opt':['--eliminate-dead-functions','--eliminate-dead-code-aggressive','--simplify-instructions','--eliminate-dead-branches','--cfg-cleanup']},'LegacyInlined':{'glslang':['-V','--target-env','vulkan1.2','-Os','-S','rgen'],'spirv_opt':['-O']}}})
opcodes=[]
for key in ['diagnostic_high_generic_dielectric','diagnostic_high_opaque_fast']:
    counts={}
    for stage in ['baseline','before','after']:
        assembly=(out/('matrix-'+stage)/key/'minimal.rgen.spvasm').read_text()
        counts[stage]=collections.Counter(re.findall(r'^\s*(?:%\S+\s*=\s*)?(Op\w+)\b',assembly,re.M))
    opcodes.append({'key':key,'counts':counts,'before_minus_baseline':{op:counts['before'][op]-counts['baseline'][op] for op in sorted(set(counts['before'])|set(counts['baseline'])) if counts['before'][op]!=counts['baseline'][op]},'prototype_minus_baseline':{op:counts['after'][op]-counts['baseline'][op] for op in sorted(set(counts['after'])|set(counts['baseline'])) if counts['after'][op]!=counts['baseline'][op]}})
save('disassembly-opcode-comparison.json',opcodes)
assert not git('diff',base,'--','src','shaders','tests','tools','assets','android','windows','CMakeLists.txt','CMakePresets.json')
save('custody.json',{'starting_local_and_remote_head':base,'branch':git('branch','--show-current'),'source_retained':base,'worktree':str(root),'final_protected_diff':'empty','worktrees_porcelain':git('worktree','list','--porcelain'),'primary_status_unchanged_from_initial':git('-C',str(root.parents[1]),'status','--short'),'protected_tree_ids':{p:git('rev-parse',base+':'+p) for p in ['src','shaders','tests','tools','docs/evidence','assets']},'restoration_note':'Only task-owned experiments were restored from starting Git blobs, with supported ABI regeneration and original Windows newline form. No reset/stash/clean/merge/rebase or worktree removal.'})
for name in ['runs.jsonl','baseline-source-identities.json','restoration-identities.json']:
    shutil.copyfile(out/name,evidence/name)
for path in out.glob('*.log'): shutil.copyfile(path,evidence/path.name)
archive=evidence/'temporary-matrices-and-rejected-prototypes.zip'
members=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(out.rglob('*')):
        if not path.is_file(): continue
        relative=path.relative_to(out).as_posix()
        data=path.read_bytes(); z.writestr(relative,data)
        members.append({'path':relative,'bytes':len(data),'sha256':sha(data)})
save('archive-manifest.json',{'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':members})
with zipfile.ZipFile(archive) as z:
    assert all(sha(z.read(m['path']))==m['sha256'] for m in members)
receipt={'schema':1,'status':'UNRESOLVED_PIPELINE_PUBLICATION_BLOCKER','source_commit':base,'accepted_source_correction':False,'source_changes_retained':[],'evidence_only_checkpoint':True,'recursive_self_commit_hash_in_receipt':False,'host_package_ready':False,'device_verified':False,'owner_audio_haptic_acceptance':'PENDING','published_pipeline_variants':0,'published_rayquery_variants':0,'compile_spirv_validation':'PASS for baseline, unchanged candidate, all retained prototypes','frozen_bounds':'FAIL: unchanged candidate all eight rows; best measurement-only prototype four Opaque rows','best_prototype_remaining_per_opaque_row':{'bytes':28,'words':7,'instructions':2},'prototype_native_complete':False,'prototype_note':'Quality-controls transport layout was a shader-only measurement. No CPU producer/dust uploader integration or native semantic proof; rejected and restored. matrix-after means unaccepted prototype, never published after-state.','required_downstream_gates':{'pipeline_freeze_check_catalog_adapters_compatibility':'NOT RUN: matrix never satisfies frozen bounds','rayquery_regeneration':'NOT RUN: shared source restored; preserve existing PS7 correction and historical freshness','transaction_fault_negative_strategy_artifact_manifest_tests':'NOT RUN this job; sources/assertions/pins unchanged','windows_debug_release_rebuild_containment':'NOT RUN: no publishable candidate','android_four_abi_debug_unsigned_release_lint_java_packaging':'NOT RUN: no publishable candidate','support_real_rig_spatial_native_regressions':'NOT RUN: source restored, no accepted correction','torch_full_sweep':'NOT REPEATED: native source dependencies unchanged at final checkpoint','physical_gpu_devices_adb_listening_haptics':'NOT RUN: expressly outside authority'},'torch_historical':{'source':base,'seconds':168.70,'margin_seconds':11.30,'poses':3287,'roof_entry_skinned_poses':1812,'plane_samples':3178,'disk_samples':57970,'timeout_seconds':180,'class':'historical; no new result'},'rayquery_historical':'d271 PS7 freshness correction preserved verbatim; no new GPU/package/device acceptance','next_owner_decision':'Review whether to authorize a separate finite frozen-budget review of the measured Opaque remainder. No budget enlargement or prototype integration occurred; a subsequent accepted candidate would still require native layout/producer proof, both shader families and full host/package gates. Other legal simplifications may exist; this bounded investigation does not prove impossibility.','files':{p.name:sha(p.read_bytes()) for p in sorted(evidence.iterdir()) if p.is_file() and p.name != 'receipt.json'}}
save('receipt.json',receipt)
table=['| Variant | Frozen bytes / words / instructions | Unchanged d271 | Unaccepted prototype |','| --- | ---: | ---: | ---: |']
for r in metrics:
    trio=lambda v:' / '.join(str(v[k]) for k in ['bytes','words','instructions'])
    table.append('| '+r['key']+' | '+trio(r['max'])+' | '+trio(r['fresh']['before'])+' | '+trio(r['fresh']['after'])+' |')
report='''# Bounded early-WP2 shader-publication investigation — unresolved

Prepared 9 October 2026. **HOST/PACKAGE-READY: NO. DEVICE-VERIFIED: NO. OWNER AUDIO/HAPTIC ACCEPTANCE: PENDING.** No source correction or generated shader package is published by this checkpoint. Only this report and new diagnostic evidence are retained.

## Custody and finite outcome

Local HEAD and the remote handoff branch were verified exactly `d271a08bd18f15bd49411000b174b89a39878479` before edits and again before checkpoint preparation. Work remained in `.worktrees/horde-1.7-wp2-vertical-proof`, branch `codex/horde-1.7-wp2-vertical-proof`. The primary checkout remains at `c3c15d3243492c8338e37ce8312b14e62e118a0b`; its existing licence/memory changes and untracked work are preserved. Readiness, diagnostic and all other worktrees are untouched. [Custody](../../evidence/2026-10-09-shader-publication-correction/custody.json) records exact refs/tree identities and inventory. No reset, stash, clean, merge, rebase or import occurred.

Supported temporary compilation established the complete current failures rather than stopping at the first byte failure. Several bounded source-equivalence experiments did not produce a candidate satisfying every unchanged maximum. The strongest shader-only transport prototype fits GenericRetained, but every OpaqueFast variant still exceeds bytes by 28, words by 7, and instructions by 2. All experiments were preserved, then undone; the protected source/test/tool/asset trees and prior evidence remain identical to d271. The restored ABI was regenerated and checked through its supported generator.

## Full frozen-bound comparison

`matrix-baseline` uses immutable 1c28d shader blobs with unchanged d271 matrix tools as a diagnostic input fixture in this worktree, not another repository/executor. Its raw SPIR-V hashes and full metrics reproduce the retained Pipeline artifacts. `matrix-before` is unchanged d271. `matrix-after` is the **unaccepted, unwired prototype**, not a published correction. The complete ten metrics, exact row invariants, dependency hashes and raw module hashes for all eight rows are in [full-metrics.json](../../evidence/2026-10-09-shader-publication-correction/full-metrics.json).

'''+ '\n'.join(table)+'''

The unchanged candidate fails only bytes, words and instructions in every row. The prototype fails only those same three maxima in the four Opaque rows. All branch-operation, loop, selection-merge, function, call, static-query-site and atomic maxima pass in the measured matrices. Generic retains 83 functions, 264 High / 261 Mobile calls and 2 query sites. Opaque retains 1 function, 0 calls and 29 High / 27 Mobile query sites. Diagnostic retains 41 Generic / 5 Opaque atomics and binding 22; Shipping retains zero atomics and no diagnostics binding. Instrumentation, quality, material and strategy match each exact row; `shippingAllowed` is checked against the unchanged manifest, not inferred from SPIR-V.

Against actual retained packages, the unchanged height shader grows 556 bytes / 139 words / 28 instructions for Generic and 568 bytes / 142 words / 29 instructions for Opaque. Old slack is 232 bytes and 17 instructions for Generic, but only 4 bytes and zero instructions for Opaque. These are frozen static artifact contracts, not measured GPU memory, frame cost or a hardware capacity limit.

## Source and disassembly diagnosis

The shared changed consumers are primary-ray origin in `rt_frame.glsl` (`+0.70 + delta`), procedural camera-relative normal in `rt_hit_decode.glsl` (`+0.75 + delta`), and staff target in `rt_atmosphere.glsl` (`+0.28 + delta`). The unchanged height delta is read from the second vec4 of binding 20's 32-byte held-light ABI. The earlier shader optimized this entire buffer out: physical lighting uses actual emitter sockets through binding 21. Height therefore activates buffer/interface/type/name/decorations in addition to access/load/arithmetic. Disassembly contains 19 new held-buffer declaration/name/type/decoration instructions (including two pointer types). Opaque's height buffer load is already hoisted once; procedural normal construction is expanded at six inlined sites. Eliminating hypothetical 29 repeated height loads is not a supported diagnosis. [Opcode comparisons](../../evidence/2026-10-09-shader-publication-correction/disassembly-opcode-comparison.json) and archived full disassemblies permit independent inspection. Exact baseline/candidate sources, dependency identities, preprocessing and resolved sources are retained.

The bounded experiments were: (1) invocation-level shared normal/staff reuse, which worsened Generic and left Opaque over; (2) explicitly appended three precomposed target vec4s at binding 20 (64-byte ABI), which also failed; (3) scalar normal subtraction preserving arithmetic order, which worsened both; (4) an explicit absolute-height vec4 appended to the already active quality buffer, improving Generic but still exceeding Opaque; (5) caching that transport only in the fully inlined strategy plus equivalent primary-mask composition; and (6) equivalent quarter-turn predicate and reuse of the same primary-hit distance in its existing consumers. The last complete matrix is retained above. No helper function was added and exact function/call/query contracts were preserved. Intermediate two-row runs are diagnostic subsets and never eight-row acceptance.

For the final **measurement-only** layout: `RtHeldLightGpu` stays 32 bytes, with physical position/strength untouched; `RtQualityControlsGpu` would append `playerWorldY` at offset 16, increasing 16 to 32 bytes. The existing uint4 quality controls stay at offset 0. Its new vec4 explicitly holds eye/normal/staff Y and a zero fourth component; no reserved control or light field is borrowed. The dust upload prefix would consequently move its array from offset 16 to 32 (11280 to 11296 total). The shader-only generator layout and consumer patch are archived, but the CPU producer/dust upload was **not integrated or built**. Thus there is no end-to-end ABI/semantic acceptance for this rejected prototype. It demonstrates a measured cost direction, not a runnable correction. The earlier 64-byte transport experiment likewise has no accepted native proof.

All existing floor/raised-support values, height composition, sockets, physical lighting, retraction/clearance, body ownership, masks, secondary contributions, planar audio response, event-time tuple/order/cancellation and lifecycle safeguards remain as d271. Nothing was removed to achieve a smaller module. Compiler strategies, optimizer passes, toolchain, maxima, dimensions and policies stayed unchanged. No frozen publication, compatibility header, catalog, adapter, hash pin or RayQuery correction was changed.

## Commands, evidence and gates

The three full matrices used PowerShell 7 and the supported `tools/compile-raygen.ps1 -Matrix -OutputDirectory <absolute temporary directory>` flow; baseline used the copied unchanged tool with pinned source fixture. Full-matrix outer times were 35.3658 s baseline, 35.4294 s unchanged candidate and 30.5942 s prototype. Each compilation, optimization, `spirv-val --target-env vulkan1.2` and disassembly completed successfully. **Matrix process exit 0 is not a frozen-budget pass.** Separate comparisons retain all failures. No deadline or compiler strategy was changed. [runs.jsonl](../../evidence/2026-10-09-shader-publication-correction/runs.jsonl) records exact argv/cwd/source/diff identity, exit, timing and raw log hash for every compiler/generator run. [Toolchain](../../evidence/2026-10-09-shader-publication-correction/toolchain.json) records executable hashes, versions and optimizer arguments.

Restoration ran `tools/generate-rt-scene-abi.ps1` (0.4771 s, exit 0), then `-Check` (0.4594 s, exit 0). All prototype source was restored; Git's protected diff is empty. No downstream publication or native/package build was attempted because the temporary matrix never met every bound. Consequently Freeze/CheckCatalog/adapter regeneration, transaction/fault/negative gates, artifact/manifest witnesses, Windows Debug/Release reconfiguration/build/containment, Android four-ABI Debug/unsigned Release/lint/Java and packaged-library checks, support/rig/spatial regression reruns are **NOT RUN in this job**. Existing tests and negative assertions remain unchanged; their historical results are not new passes.

The current package policy would require Diagnostic/High on Windows Debug, Shipping/High on Release; Android Diagnostic/Mobile and Shipping/Mobile respectively. Windows exact EXE containment has registered positive/negative/registration checks. The existing Android package helper inspects **arm64-v8a only**. Other ABI entries would need supported APK-to-stripped-library hash and ELF/alignment inspection; that cannot be relabelled all-ABI SPIR-V scanning. Neither inspection happened here, and no stale package was used to manufacture readiness.

The original d271 torch pass remains historical: 168.70 s, 11.30 s margin under unchanged 180 s, 3287 / 1812 / 3178 / 57970 coverage. It was not repeated because the final source/native dependencies are unchanged and no accepted correction exists. The earlier WP0 180.03 s timeout and focused 168.85 s diagnostic remain verbatim. The PowerShell 7 RayQuery dependency-serialization correction and final freshness receipt remain unchanged; this job makes no new Query freshness/presentation claim.

The archive [temporary-matrices-and-rejected-prototypes.zip](../../evidence/2026-10-09-shader-publication-correction/temporary-matrices-and-rejected-prototypes.zip) retains actual SPIR-V, preprocessed/resolved sources, disassemblies, stats, input fixture, rejected patches and helper scripts. [Archive manifest](../../evidence/2026-10-09-shader-publication-correction/archive-manifest.json) binds every member's byte length/SHA-256 and the whole ZIP; extraction hashes were verified. It is diagnostic evidence, not runtime admission. [Receipt](../../evidence/2026-10-09-shader-publication-correction/receipt.json) binds all logs/metrics without a recursive self-commit hash.

## Review decision and stop

Review whether to authorize a **separate finite frozen-budget review** of the measured Opaque remainder before further integration. This task did not enlarge any limit or invoke that mechanism. Further legal source simplifications may exist; the bounded experiments do not prove impossibility. Even an approved future budget decision would not accept this unwired prototype: native producer/layout proof, fresh Pipeline and Query publication, exact identities, negative checks and all required host/package gates would still remain.

No phone/ADB, installation, GPU presentation, physical acceptance, listening or haptics occurred. Exact-target Pipeline/Query presentation, traversal/look/body/equipment/light/off-camera effects and both platforms' lifecycle/recovery checks remain deferred. **DEVICE-VERIFIED remains NO; owner audio/haptic acceptance remains PENDING.** Stop at this unresolved evidence checkpoint. No other WP2 slice or release is started.

Immutable source: [d271 handoff](https://github.com/Samfa12-tech/The-Horde-RT-demo/tree/d271a08bd18f15bd49411000b174b89a39878479), [runtime baseline 1c28d](https://github.com/Samfa12-tech/The-Horde-RT-demo/tree/1c28d0563a897dc72d410bdb2b61723e66ed92af), [unchanged compiler](https://github.com/Samfa12-tech/The-Horde-RT-demo/blob/d271a08bd18f15bd49411000b174b89a39878479/tools/compile-raygen.ps1), [unchanged frozen maxima](https://github.com/Samfa12-tech/The-Horde-RT-demo/blob/d271a08bd18f15bd49411000b174b89a39878479/tools/raygen-variant-budgets.json). No correction source commit is created because no candidate qualified; the subsequent checkpoint is evidence-only.
'''
(root/'docs/superpowers/plans/2026-10-09-horde-1.7-shader-publication-correction.md').write_text(report,encoding='utf-8')
(evidence/'.gitattributes').write_text('*.zip -filter -diff -merge -text\n*.log -text whitespace=-trailing-space,-blank-at-eof,cr-at-eol\n*.json text eol=lf\n*.jsonl text eol=lf\n',encoding='utf-8')
print(json.dumps({'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'members':len(members),'evidence_files':len(list(evidence.iterdir()))}))
