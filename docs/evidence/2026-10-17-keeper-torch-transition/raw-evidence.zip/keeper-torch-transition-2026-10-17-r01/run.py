from pathlib import Path
import subprocess,json,time,sys
sys.path.insert(0,str(Path('tools').resolve()))
from android_current_thermal_state import parse_current_thermal_state
adb='C:/Users/sam_s/AppData/Local/Android/Sdk/platform-tools/adb.exe';base=[adb,'-s','R5GL219SZGK'];pkg='com.samfa12.hordelanternrt.debug';act=pkg+'/com.samfa12.hordelanternrt.MainActivity'
root=Path('reports/keeper-torch-transition-2026-10-17-r01')
def call(*a,ok=True):
 p=subprocess.run(base+list(a),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 if ok and p.returncode:raise RuntimeError((a,p.stderr.decode(errors='replace')))
 return p.stdout
def foreground():
 raw=call('shell','dumpsys','window').decode(errors='replace');focus=[s for s in raw.splitlines() if 'mCurrentFocus=' in s]
 if not any(pkg+'/' in s for s in focus):raise RuntimeError('Owned Debug is not foreground: '+str(focus))
def thermal(out):
 raw=call('shell','dumpsys','thermalservice');out.write_bytes(raw);return parse_current_thermal_state(raw.decode())
case=sys.argv[1];mode='query' if case.startswith('query') else 'pipeline';out=root/case;out.mkdir(exist_ok=False)
runid='torch-'+case+'-r01';scenario='keeper-torch-transition'
call('shell','am','force-stop',pkg)
print('prepare thermal',json.dumps(thermal(out/'thermal-before-prepare.txt')),flush=True)
(out/'launch.txt').write_bytes(call('shell','am','start','-W','--user','0','-n',act,'--es','horde.debug.checkpoint','rescue-journey-start','--ez','horde.debug.capture','false','--ez','horde.debug.gpu_timing','true','--ez','horde_require_rayquery_compute','true' if mode=='query' else 'false'))
time.sleep(3);pid=call('shell','pidof',pkg).decode().strip();deadline=time.monotonic()+120
while time.monotonic()<deadline:
 log=call('logcat','-d','--pid='+pid).decode(errors='replace')
 raw=call('exec-out','run-as',pkg,'cat','files/reports/vulkan_capability_report.json',ok=False)
 try:d=json.loads(raw)
 except ValueError:time.sleep(2);continue
 if 'HORDE_LIVE_CHAPTER checkpoint=rescue-journey-start' in log and d.get('rtScene',{}).get('presented') and d.get('executionBackend')==('RayQueryCompute' if mode=='query' else 'RayTracingPipeline'):
  foreground();(out/'prestart-capability.json').write_bytes(raw);(out/'prestart.log').write_text(log);break
 time.sleep(2)
else:raise RuntimeError('Current live chapter did not present within startup limit')
foreground();thermal(out/'thermal-before-route.txt')
assert call('exec-out','run-as',pkg,'cat','shared_prefs/horde_lantern_alpha_settings.xml')==(root/'settings-before.xml').read_bytes()
(out/'motion-launch.txt').write_bytes(call('shell','am','start','-W','--user','0','-n',act,'--es','horde.debug.motion',scenario,'--es','horde.debug.motion_id',runid,'--ez','horde.debug.gpu_timing','true','--ez','horde_require_rayquery_compute','true' if mode=='query' else 'false'))
visual='visual' in case
captured=set()
deadline=time.monotonic()+155
while time.monotonic()<deadline:
 foreground()
 if visual:
  resource=call('exec-out','run-as',pkg,'cat','files/reports/android-motion-'+runid+'-resources.csv',ok=False)
  complete=resource.decode(errors='replace').splitlines()
  phase=complete[-1].split(',')[4] if len(complete)>1 and len(complete[-1].split(','))>4 else ''
  if phase in ('torch-baseline','torch-lit') and phase not in captured:
   (out/(phase+'-before.csv')).write_bytes(resource)
   (out/(phase+'.png')).write_bytes(call('exec-out','screencap','-p'));captured.add(phase)
   (out/(phase+'-after.csv')).write_bytes(call('exec-out','run-as',pkg,'cat','files/reports/android-motion-'+runid+'-resources.csv',ok=False))
 raw=call('exec-out','run-as',pkg,'cat','files/reports/android-motion-'+runid+'-manifest.json',ok=False)
 try:r=json.loads(raw)
 except ValueError:time.sleep(.3 if visual else 4);continue
 if r.get('finished') or r.get('failure'):
  print('terminal',case,r.get('complete'),r.get('failure'),flush=True);break
 time.sleep(4)
for name in [f'android-motion-{runid}-manifest.json',f'android-motion-{runid}-ledger.json',f'android-motion-{runid}-resources.csv',f'android-motion-{runid}-present-timing.json','HordeLanternRT-benchmark-latest.json','vulkan_capability_report.json']:
 data=call('exec-out','run-as',pkg,'cat','files/reports/'+name,ok=False)
 if data:(out/name).write_bytes(data)
thermal(out/'thermal-after.txt');foreground();(out/'final.png').write_bytes(call('exec-out','screencap','-p'))
(out/'owned-final.log').write_bytes(call('logcat','-d','--pid='+pid,ok=False))
after=call('exec-out','run-as',pkg,'cat','shared_prefs/horde_lantern_alpha_settings.xml');(out/'settings-after.xml').write_bytes(after);assert after==(root/'settings-before.xml').read_bytes()
call('shell','am','force-stop',pkg);print('Debug stopped; prefs identical',flush=True)
