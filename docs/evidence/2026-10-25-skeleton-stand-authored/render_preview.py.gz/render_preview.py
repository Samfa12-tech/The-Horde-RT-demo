"""Read the saved proof; render one offline studio batch. Never save a blend."""
import bpy, pathlib, json, math, hashlib
from mathutils import Vector
OUT=pathlib.Path(__file__).resolve().parent
AUTHOR=bpy.context.scene
arm=next(o for o in AUTHOR.objects if o.type=='ARMATURE')
mesh=bpy.data.objects['char1']
assert hashlib.sha256(pathlib.Path(bpy.data.filepath).read_bytes()).hexdigest()=='afd08e9642dea9a399b49588f8a634b7a2f8f503f3f3750fc981bf17d9bbc6bc'
take=bpy.data.actions['SkeletonProof|StandDead0ToIdle']
data=json.loads((OUT/'authoring-contact.json').read_text())
inspect=json.loads((OUT/'rig-inspection.json').read_text())
def update():bpy.context.view_layer.update()
def set_action(a,action,frame):
 a.animation_data.action=action;a.animation_data.action_slot=action.slots[0]
def points(m):
 ev=m.evaluated_get(bpy.context.evaluated_depsgraph_get());sm=ev.to_mesh()
 result=[ev.matrix_world@v.co for v in sm.vertices];ev.to_mesh_clear();return result
def geometry(m):
 return hashlib.sha256(repr(([tuple(v.co) for v in m.data.vertices],
  [tuple(p.vertices) for p in m.data.polygons],[[tuple(x.uv) for x in layer.data] for layer in m.data.uv_layers],
  [[(g.group,g.weight) for g in v.groups] for v in m.data.vertices])).encode()).hexdigest()
original_geometry=geometry(mesh)
original_bind={b.name:[list(row) for row in b.matrix_local] for b in arm.data.bones}
expected_bind={b['name']:b['matrix'] for b in inspect['bones']}
assert original_bind==expected_bind
endpoints={}
for name in ['Dead','Idle_5']:
 set_action(arm,bpy.data.actions[name],0);AUTHOR.frame_set(0);update();endpoints[name]=points(mesh)
set_action(arm,take,1)
contact=[]
for half in range(181):
 frame=1+half*.5;AUTHOR.frame_set(int(frame),subframe=frame-int(frame));p=points(mesh);u=(frame-1)/90
 row={'authorFrame':frame,'seconds':(frame-1)/60,'meshMinimumZ':min(x.z for x in p),'feet':{}}
 for side,begin,end in [('Right',.06,.46),('Left',.54,.94)]:
  phase=max(0.,min(1.,(u-begin)/(end-begin)));stance='initial' if phase==0 else 'final' if phase==1 else 'swing'
  indices=data['soleVertexIndices'][side];reference=endpoints['Dead' if stance=='initial' else 'Idle_5']
  row['feet'][side]={'stance':stance,'soleMinimumZ':min(p[i].z for i in indices),'soleMaximumZ':max(p[i].z for i in indices),
   'supportHorizontalDriftM':max(Vector((p[i].x-reference[i].x,p[i].y-reference[i].y)).length for i in indices) if stance!='swing' else None}
 if half in [0,180]:row['sourceEndpointMaxVertexErrorM']=max((a-b).length for a,b in zip(p,endpoints['Dead' if half==0 else 'Idle_5']))
 contact.append(row)
assert geometry(mesh)==original_geometry

# Preview-only layout helpers are never exported or saved to the original proof.
# Quarter shows the two retained facing directions side by side; the side studio
# spaces the same two instances across the camera to avoid mutual occlusion.
views=[]
for label,positions,camera_location,look,scale in [
 ('quarter',[(0,.75,0),(0,-.75,0)],(4,-4.2,2.8),(0,0,.65),3.35),
 ('side',[(-1.05,0,0),(1.05,0,0)],(0,-5,2.6),(0,0,.65),3.9)]:
 scene=bpy.data.scenes.new('PREVIEW ONLY '+label);scene.render.fps=30
 bpy.context.window.scene=scene
 actors=[]
 for index,location in enumerate(positions):
  root=bpy.data.objects.new('PREVIEW static actor '+str(index),None);scene.collection.objects.link(root)
  root.location=location;root.rotation_euler.z=math.pi/2
  a=arm.copy();a.name=label+' actor '+str(index);scene.collection.objects.link(a);a.parent=root
  m=mesh.copy();m.name=label+' mesh '+str(index);scene.collection.objects.link(m)
  m.parent=a if mesh.parent==arm else root
  for modifier in m.modifiers:
   if modifier.type=='ARMATURE':modifier.object=a
  m.color=(.78,.74,.64,1);actors.append(a)
 scene.render.engine='BLENDER_WORKBENCH';scene.render.resolution_x=960;scene.render.resolution_y=640;scene.render.resolution_percentage=100
 scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
 scene.display.shading.light='STUDIO';scene.display.shading.color_type='OBJECT'
 scene.display.shading.show_shadows=True;scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH'
 scene.display.shading.show_object_outline=True;scene.display.shading.background_type='WORLD';scene.display.render_aa='8'
 scene.world=bpy.data.worlds.new('PREVIEW world '+label);scene.world.color=(.06,.065,.075)
 bpy.ops.mesh.primitive_plane_add(size=6,location=(0,0,0));floor=bpy.context.object;floor.name='PREVIEW ONLY floor';floor.color=(.23,.25,.28,1)
 for axis in [0,1]:
  for cell in range(-5,6):
   xyz=[0.,0.,.0003];xyz[axis]=cell*.5
   bpy.ops.mesh.primitive_cube_add(size=1,location=xyz);line=bpy.context.object
   line.name='PREVIEW ONLY 0.5m grid';line.scale=(.0015,3,.0003) if axis==0 else (3,.0015,.0003);line.color=(.5,.52,.55,1)
 camera_data=bpy.data.cameras.new('PREVIEW '+label);camera=bpy.data.objects.new('PREVIEW '+label,camera_data);scene.collection.objects.link(camera)
 camera.location=camera_location;camera.rotation_euler=(Vector(look)-camera.location).to_track_quat('-Z','Y').to_euler()
 camera_data.type='ORTHO';camera_data.ortho_scale=scale;scene.camera=camera
 directory=OUT/('preview-'+label);directory.mkdir(exist_ok=False)
 views.append((label,scene,actors,directory))

sequence=[]
for i in range(15):sequence.append(('corpse hold','Dead',178))
for i in range(90):sequence.append(('reverse existing Dead','Dead',178-i*2))
for i in range(15):sequence.append(('Dead0 join hold','Dead',0))
for i in range(45):sequence.append(('authored stand','SkeletonProof|StandDead0ToIdle',3+i*2))
for i in range(30):sequence.append(('ordinary Idle','Idle_5',i*2))
manifest=[]
for label,scene,actors,directory in views:
 bpy.context.window.scene=scene
 for index,(phase,clip,frame) in enumerate(sequence):
  for a in actors:set_action(a,bpy.data.actions[clip],frame)
  scene.frame_set(frame);update()
  scene.render.filepath=str(directory/f'{index:04d}.png')
  bpy.ops.render.render(write_still=True,scene=scene.name)
  manifest.append({'view':label,'frame':index,'seconds':index/30,'phase':phase,'clip':clip,'sourceFrame':frame,'file':str(scene.render.filepath)})
  if index%30==0:print('PREVIEW_PROGRESS',label,index,len(sequence),flush=True)
 # Detailed same-camera contact witnesses are original rendered images with
 # exact authored times; do not generate interpolated frames or edit the poses.
print('PREVIEW_BATCH_FINISHED',flush=True)
result={'evidenceClass':'Blender Workbench offline authoring preview; not game RT, real-time rendering FPS, native loader or phone acceptance',
 'savedBlendSha256':hashlib.sha256(pathlib.Path(bpy.data.filepath).read_bytes()).hexdigest(),
 'sourceGeometryWeightsUvsUnchanged':geometry(mesh)==original_geometry,'restBindUnchanged':original_bind==expected_bind,
 'savedBlendNotWritten':True,'contactSampleHz':120,'contactSamples':contact,
 'reopenedMaximumSupportDriftM':max(f['supportHorizontalDriftM'] for row in contact for f in row['feet'].values() if f['supportHorizontalDriftM'] is not None),
 'reopenedMinimumMeshZ':min(row['meshMinimumZ'] for row in contact),'previewSampleHz':30,'framesPerView':len(sequence),'frames':manifest,
 'viewStaging':'Static preview-only instance wrappers; side-studio spacing avoids occlusion. No actor transform or preview helper is exported.'}
(OUT/'preview-contact.json').write_text(json.dumps(result,indent=2)+'\n')
