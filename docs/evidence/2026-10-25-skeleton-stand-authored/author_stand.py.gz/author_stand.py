"""One private same-rig stand proof, adapted from the existing Kit authoring recipe."""
import bpy, pathlib, hashlib, json, math
from mathutils import Vector, Matrix
OUT=pathlib.Path(__file__).resolve().parent
ROOT=OUT.parents[1]
SOURCE=ROOT/'assets/models/enemies/meshy/skeleton_biped_merged_animations_v01.glb'
SOURCE_HASH='340a8a354bd57a8167da84fc26ccdfe03c5ef536195e260cd27c24e0059de6db'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==SOURCE_HASH
assert not (OUT/'skeleton-stand-proof.blend').exists()
FPS=60;LAST=91

def smooth(t):
 t=max(0.,min(1.,t));return t*t*(3-2*t)
def update():bpy.context.view_layer.update()
def points(mesh):
 ev=mesh.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh()
 result=[ev.matrix_world@v.co for v in m.vertices];ev.to_mesh_clear();return result
def bind(arm):return {b.name:[list(row) for row in b.matrix_local] for b in arm.data.bones}
def geometry(mesh):
 return hashlib.sha256(repr(([tuple(v.co) for v in mesh.data.vertices],
  [tuple(p.vertices) for p in mesh.data.polygons],[[tuple(x.uv) for x in layer.data] for layer in mesh.data.uv_layers],
  [[(g.group,g.weight) for g in v.groups] for v in mesh.data.vertices])).encode()).hexdigest()
def activate(action,frame):
 arm.animation_data.action=action;arm.animation_data.action_slot=action.slots[0]
 scene.frame_set(frame);update()
def world(name):return arm.matrix_world@arm.pose.bones[name].matrix
def interpolate(a,b,t):
 x,q,s=a.decompose();y,r,v=b.decompose()
 return Matrix.LocRotScale(x.lerp(y,t),q.slerp(r,t),s.lerp(v,t))
def leg(side,target):
 # Existing two-bone offline authoring construction. No runtime solver, no
 # bone-length stretch: an unreachable request is clamped and recorded.
 names=[side+n for n in ('UpLeg','Leg','Foot')]
 base={n:world(n).copy() for n in names}
 h=base[names[0]].translation;k0=base[names[1]].translation;a0=base[names[2]].translation
 l1=(k0-h).length;l2=(a0-k0).length;delta=target.translation-h;raw=delta.length
 length=min(max(raw,abs(l1-l2)+1e-6),l1+l2-1e-6);axis=delta.normalized()
 ankle=h+axis*length
 pole=k0-h-(a0-h)*((k0-h).dot(a0-h)/max((a0-h).length_squared,1e-12))
 pole-=axis*pole.dot(axis)
 if pole.length<1e-6:pole=Vector((0,-1,0))-axis*axis.dot(Vector((0,-1,0)))
 pole.normalize();along=(l1*l1-l2*l2+length*length)/(2*length)
 knee=h+axis*along+pole*math.sqrt(max(0.,l1*l1-along*along))
 q1=(k0-h).rotation_difference(knee-h);q2=(a0-k0).rotation_difference(ankle-knee)
 inv=arm.matrix_world.inverted()
 for n,q,p in [(names[0],q1,h),(names[1],q2,knee)]:
  m=q.to_matrix().to_4x4()@base[n];m.translation=p
  arm.pose.bones[n].matrix=inv@m;update()
 m=target.copy();m.translation=ankle;arm.pose.bones[names[2]].matrix=inv@m;update()
 return (ankle-target.translation).length

bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene;scene.name='AUTHOR - one contact-aware stand proof';scene.render.fps=FPS
bpy.ops.import_scene.gltf(filepath=str(SOURCE))
arm=next(o for o in scene.objects if o.type=='ARMATURE');mesh=bpy.data.objects['char1']
for track in arm.animation_data.nla_tracks:track.mute=True
for action in bpy.data.actions:action.use_fake_user=True
original_bind=bind(arm);original_geometry=geometry(mesh);original_world=[list(row) for row in arm.matrix_world]
endpoint={}
for name in ['Dead','Idle_5']:
 activate(bpy.data.actions[name],0)
 endpoint[name]={'basis':{p.name:p.matrix_basis.copy() for p in arm.pose.bones},
  'world':{p.name:world(p.name).copy() for p in arm.pose.bones},'points':points(mesh)}
sole={}
for side in ['Left','Right']:
 groups={mesh.vertex_groups[side+n].index for n in ['UpLeg','Leg','Foot','ToeBase']}
 candidates=[v.index for v in mesh.data.vertices if v.groups and all(g.group in groups for g in v.groups if g.weight>1e-5)
             and min(endpoint[x]['points'][v.index].z for x in endpoint)<.25]
 indices=set()
 for name in endpoint:
  low=min(endpoint[name]['points'][i].z for i in candidates)
  indices.update(i for i in candidates if endpoint[name]['points'][i].z<=low+.006)
 assert len(indices)>=3
 sole[side]=sorted(indices)
arm.animation_data.action=None
action=bpy.data.actions.new('SkeletonProof|StandDead0ToIdle');action.use_fake_user=True
arm.animation_data.action=action
rows=[];maximum_reach_error=0;maximum_endpoint_error=0
for frame in range(1,LAST+1):
 scene.frame_set(frame);u=(frame-1)/(LAST-1);body=smooth((u-.04)/.92)
 for p in arm.pose.bones:
  p.rotation_mode='QUATERNION'
  p.matrix_basis=interpolate(endpoint['Dead']['basis'][p.name],endpoint['Idle_5']['basis'][p.name],body)
 update()
 phases={side:max(0.,min(1.,(u-start)/(end-start))) for side,start,end in [('Right',.06,.46),('Left',.54,.94)]}
 if frame not in [1,LAST]:
  first=math.sin(math.pi*phases['Right'])**2;second=math.sin(math.pi*phases['Left'])**2
  pelvis=world('Hips').copy();pelvis.translation+=Vector((.035*first-.025*second,.035*(first+second),-.020*(first+second)))
  arm.pose.bones['Hips'].matrix=arm.matrix_world.inverted()@pelvis;update()
  for side in ['Right','Left']:
   t=smooth(phases[side]);m=interpolate(endpoint['Dead']['world'][side+'Foot'],endpoint['Idle_5']['world'][side+'Foot'],t)
   m.translation.z+=.085*math.sin(math.pi*phases[side])**2
   maximum_reach_error=max(maximum_reach_error,leg(side,m))
   arm.pose.bones[side+'ToeBase'].matrix_basis=interpolate(endpoint['Dead']['basis'][side+'ToeBase'],endpoint['Idle_5']['basis'][side+'ToeBase'],t)
   update()
 for p in arm.pose.bones:
  p.keyframe_insert('location',frame=frame);p.keyframe_insert('rotation_quaternion',frame=frame);p.keyframe_insert('scale',frame=frame)
 p=points(mesh);row={'frame':frame,'seconds':(frame-1)/FPS,'feet':{},'minimumMeshZ':min(x.z for x in p)}
 for side in ['Left','Right']:
  phase=phases[side];stance='initial' if phase==0 else 'final' if phase==1 else 'swing'
  ideal=endpoint['Dead' if stance=='initial' else 'Idle_5']['points']
  row['feet'][side]={'stance':stance,'supportSoleMaxHorizontalDriftM':max(Vector((p[i].x-ideal[i].x,p[i].y-ideal[i].y)).length for i in sole[side]) if stance!='swing' else None,
   'soleMinimumZ':min(p[i].z for i in sole[side]),'soleMaximumZ':max(p[i].z for i in sole[side])}
 if frame in [1,LAST]:
  reference=endpoint['Dead' if frame==1 else 'Idle_5']['points'];error=max((a-b).length for a,b in zip(p,reference));maximum_endpoint_error=max(maximum_endpoint_error,error)
  row['exactSourceEndpointMaxVertexErrorM']=error
 rows.append(row)
for layer in action.layers:
 for strip in layer.strips:
  for slot in action.slots:
   bag=strip.channelbag(slot)
   if bag:
    for curve in bag.fcurves:
     for key in curve.keyframe_points:key.interpolation='LINEAR'
scene.frame_start=1;scene.frame_end=LAST;scene.frame_set(1)
scene['evidence']='Private offline Blender authoring proof, not native RT or runtime admission.'
scene['source_sha256']=SOURCE_HASH
scene['contact_plan']='Right foot steps .06-.46; left foot steps .54-.94. Opposite foot has fixed authored world pose. Pelvis shifts over support. No animated actor root.'
assert bind(arm)==original_bind and geometry(mesh)==original_geometry and [list(row) for row in arm.matrix_world]==original_world
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'skeleton-stand-proof.blend'),compress=True)
summary={'sourceSha256':SOURCE_HASH,'blender':bpy.app.version_string,'clip':action.name,'durationSeconds':1.5,'frameCount':LAST,
 'sourceGeometryWeightsUvsUnchanged':geometry(mesh)==original_geometry,'restBindUnchanged':bind(arm)==original_bind,'armatureWorldAndScaleUnchanged':[list(row) for row in arm.matrix_world]==original_world,
 'maxRequiredReachCorrectionM':maximum_reach_error,'maxSourceEndpointVertexErrorM':maximum_endpoint_error,
 'maximumSupportSoleHorizontalDriftM':max(f['supportSoleMaxHorizontalDriftM'] for row in rows for f in row['feet'].values() if f['supportSoleMaxHorizontalDriftM'] is not None),
 'minimumMeshZ':min(row['minimumMeshZ'] for row in rows),'soleVertexIndices':sole,'frames':rows,
 'nativeLoaderAdmission':'Pending; this receipt is offline authoring only. No canonical game-dev package or production binding.'}
(OUT/'authoring-contact.json').write_text(json.dumps(summary,indent=2)+'\n')
print('AUTHORED_STAND',json.dumps({k:v for k,v in summary.items() if k not in ['frames','soleVertexIndices']}),flush=True)
